# high-dimensional-ode-solver-experiments

Short: "hose".