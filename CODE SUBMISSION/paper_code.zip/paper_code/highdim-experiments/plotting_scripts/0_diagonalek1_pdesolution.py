import pathlib

from hose import plotting

result_dir = pathlib.Path("./results/0_diagonalek1_pdesolution")
plotting.plot_0_diagonalek1_pdesolution(result_dir)
