"""Visualisation of the 3rd experiment (Figure 4)."""
import pathlib

from hose import plotting

path = pathlib.Path("./results/3_dimension_vs_runtime/results.csv")
plotting.plot_3_dimension_vs_runtime(path)
