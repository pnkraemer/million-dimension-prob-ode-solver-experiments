"""Visualisation of the 1st experiment (Figure 2)."""
import pathlib

from hose import plotting

path = pathlib.Path("./results/1_sterilised_problem/results.csv")
plotting.plot_1_sterilised_problem(path)
