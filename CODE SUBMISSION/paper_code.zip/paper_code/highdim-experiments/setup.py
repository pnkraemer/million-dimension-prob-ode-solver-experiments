"""Make the source installable in editable mode by having a setup.py next to the setup.cfg."""
from setuptools import setup

setup()
