# ICML 2022 paper submission: "Probabilistic ODE Solutions in Millions of Dimensions"

## What is provided?

On the same level as this `README.md` file you will find two directories containing Python code.
This code supplements the written manuscript of the ICML submission and consists of two parts

1. `tornadox`: This small software package is based almost entirely on `jax` and implements the methods that are described in the paper. This includes
    * reference implementations of state-of-the-art filtering-based probabilistic ODE solvers
    * the methods that build upon the above that are proposed in the submission

2. `highdim-experiments` bundles a) the code that produces the results shown in the **Experiments**-section and b) the plotting code that produces all the figures in the manuscript.
Furthermore, the binary files containing the experiment results are provided in `highdim-experiments/results`.


## [ Important ] Q0: How do I set everything up?

First, the two packages have to be installed, together with the required Python packages. In order to do so simply follow these steps:

0. Make sure you are in the directory that contains
```
paper_code/
|
|___ highdim-experiments/
|___ tornadox/
|___ README.md
```
i.e., the directory in which this very file is located.

1. Navigate to `tornadox`
```bash
cd tornadox/
```

2. Install `tornadox` via pip (editable, `-e`)
```bash
pip3 install -e .
```

3. Navigate back to the root directory and then to the `highdim-experiments` directory:
```bash
cd ..
cd highdim-experiments
```

4. Install this package via pip, as well
```bash
pip3 install -e .
```

> Now, you have installed the provided code as python packages, such that you can easily import the functions and classes needed.


## Q1: I want to reproduce the figures from the results. How do I do that?

> Make sure you have followed the steps above and installed the provided code packages via `pip install` (see Q0 above).

Find the plotting scripts in the directory `highdim-experiments/plotting_scripts`.
For five figures that are contained in the paper, we provide five Python scripts that produce them from the results (`highdim-experiments/results`).

> Note: In the directory `highdim-experiments/results`, we provide the results from the experiments as presented and detailed in the paper. If you accidentally deleted the `results` folder,or you want to reproduce the results, follow the steps in the next question (Q2 below) to reproduce them.

For example, to produce Figure 1,

0. If not already there, navigate to the directory `highdim-experiments`.
```bash
cd highdim-experiments
```

1. Execute the respective plotting code. This will save a `.pdf`-file to the respective subfolder of `highdim-experiments/results/`.

```bash
python3 plotting_scripts/0_diagonalek1_pdesolution.py
```

2. Find the plot as the PDF-file `results/0_diagonalek1_pdesolution/0_diagonalek1_pdesolution.pdf`



## Q2: I want to reproduce the results presented in the paper, from scratch. How do I do that?

> Make sure you have followed the steps above and installed the provided code packages via `pip install` (see Q0 above).

You will find the experiment code in the folder `highdim-experiments/experiments`.
These are several Python scripts, in which a leading index number indicates, which experiment is run with which script.

We will exemplary reproduce the results of Figure 3.

0. If not already there, navigate to the directory `highdim-experiments`.
```bash
cd highdim-experiments
```

1. Execute all python scripts related to this experiment. In this case, we have the index number `2`, hence execute

```bash
python3 experiments/2_medium_scale_problem.py
python3 experiments/2_medium_scale_plotting_code.py
```

This saves binary files containing the results as `(jax.)numpy`-arrays to the respective subfolder of the `results`-directory.
To plot the results, follow the instructions in the previous question (Q1).